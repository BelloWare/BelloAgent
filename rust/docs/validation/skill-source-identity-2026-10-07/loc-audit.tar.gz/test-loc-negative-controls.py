#!/usr/bin/env python3
"""Tamper controls run only on in-memory copies; source and Git stay untouched."""
import copy
import importlib.util
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('verifier', HERE/'verify-skill-path-loc.py')
v = importlib.util.module_from_spec(spec)
spec.loader.exec_module(v)

def main():
    args = v.arguments()
    report = json.loads(args.report.read_text())
    original = v.load_inputs(args)
    v.verify_report(report, *original)
    results = []
    def reject(name, action):
        try:
            action()
        except (v.VerificationError, subprocess.CalledProcessError) as error:
            results.append({'name': name, 'result': 'passed', 'rejected_with': str(error)})
        else:
            raise AssertionError('negative control accepted: ' + name)
    def input_mutation(index, change):
        values = list(original)
        if isinstance(values[index], dict):
            values[index] = values[index].copy()
        values[index] = change(values[index])
        return v.verify_report(report, *values)
    def edit_source(sources, path, suffix=b'\n// unexpected audit control\n'):
        sources[path] += suffix
        return sources
    def drop_source(sources, path):
        del sources[path]
        return sources
    def add_source(sources, path):
        sources[path] = b'fn unexpected() {}\n'
        return sources
    def report_mutation(change):
        altered = copy.deepcopy(report)
        change(altered)
        return v.verify_report(altered, *original)
    reject('changed production source', lambda: input_mutation(2, lambda x: edit_source(x, v.SOURCE)))
    reject('changed test source', lambda: input_mutation(2, lambda x: edit_source(x, v.IDENTITY)))
    reject('missing source', lambda: input_mutation(2, lambda x: drop_source(x, v.SOURCE)))
    reject('extra Rust file', lambda: input_mutation(2, lambda x: add_source(x, v.CORE+'src/unexpected.rs')))
    reject('non-Rust Swift oracle drift', lambda: input_mutation(2, lambda x: edit_source(x, v.CORE+'tests/fixtures/project_skills_oracle.swift')))
    reject('non-Rust validation document drift', lambda: input_mutation(2, lambda x: edit_source(x, 'rust/docs/validation/project-skills-native-oracle.md')))
    reject('unrelated unchanged Rust drift', lambda: input_mutation(2, lambda x: edit_source(x, v.READ_TEST)))
    reject('baseline source drift', lambda: input_mutation(1, lambda x: edit_source(x, v.RESOURCE)))
    reject('immutable Skills ledger copy drift', lambda: input_mutation(4, lambda x: x+b' '))
    reject('frozen manifest drift', lambda: input_mutation(3, lambda x: x+b' '))
    reject('immutable Bash ledger copy drift', lambda: input_mutation(5, lambda x: x+b' '))
    reject('historical Bash bridge preimage drift', lambda: input_mutation(6, lambda x: edit_source(x, v.COMP)))
    reject('historical source-path audit drift', lambda: input_mutation(7, lambda x: x+b' '))
    reject('compaction inherited span tampering', lambda: report_mutation(lambda x: next(f for f in x['baseline_bridge']['files'] if f['path']==v.COMP)['after']['classification_spans'][0].__setitem__('classification', v.KEYS[0])))
    reject('wrong baseline tree', lambda: v.verify_ref(args.repo, v.SKILLS_TREE, v.BASE_TREE))
    reject('blob passed as baseline', lambda: v.verify_ref(args.repo, v.blob(original[1][v.RESOURCE]), v.BASE_TREE))
    reject('total count tampering', lambda: report_mutation(lambda x: x.__setitem__('after_total', x['after_total']+1)))
    reject('baseline bridge delta tampering', lambda: report_mutation(lambda x: x['baseline_bridge']['delta'].__setitem__(v.KEYS[1], 10)))
    reject('source digest tampering', lambda: report_mutation(lambda x: x['files'][0]['after']['source'].__setitem__('sha256', '0'*64)))
    reject('changed-span evidence tampering', lambda: report_mutation(lambda x: x['files'][0]['changed_line_spans'][0].__setitem__('source_sha256', '0'*64)))
    reject('preserved-span evidence tampering', lambda: report_mutation(lambda x: x['files'][0]['preserved_line_ranges'][0].__setitem__('source_sha256', '0'*64)))
    reject('classification provenance tampering', lambda: report_mutation(lambda x: x['files'][0]['before_classification_origin'].__setitem__('sha256', '0'*64)))
    reject('test gate extent tampering', lambda: report_mutation(lambda x: x['files'][0]['after']['classification_spans'][1].__setitem__('end', 25)))
    reject('false publication claim', lambda: report_mutation(lambda x: x.__setitem__('publication_commit', v.BASE_COMMIT)))
    def self_consistent_reclassification(x):
        row = next(f for f in x['files'] if f['path'] == v.SOURCE)
        amount = row['after']['nonblank']
        row['after']['classification_spans'][0]['classification'] = v.KEYS[1]
        for obj in (row['after']['counts'], row['delta'], x['delta'], x['after_counts']):
            obj[v.KEYS[0]] -= amount
            obj[v.KEYS[1]] += amount
        for change in row['changed_line_spans']:
            change['classification'] = v.KEYS[1]
    reject('self-consistent helper reclassification', lambda: report_mutation(self_consistent_reclassification))
    reject('equal-line reclassification', lambda: v.evidence(['unchanged'], ['unchanged'], [v.KEYS[0]], [v.KEYS[1]]))
    # Controls that must succeed: baseline commit alias and empty/blank line behavior.
    v.verify_ref(args.repo, v.BASE_COMMIT, v.BASE_TREE)
    preserved, changed, delta = v.evidence(['same', ''], ['same', '', '// comment'], [v.KEYS[0]]*2, [v.KEYS[0]]*3)
    assert delta == dict(zip(v.KEYS, (1, 0, 0)))
    print(json.dumps({'result': 'passed', 'negative_controls': len(results),
                      'controls': results, 'positive_controls': ['baseline commit resolves to pinned tree', 'blank ignored; comment counted'],
                      'source_mutations': 'in-memory only', 'source_and_git_untouched': True}, indent=2))

if __name__ == '__main__':
    main()
