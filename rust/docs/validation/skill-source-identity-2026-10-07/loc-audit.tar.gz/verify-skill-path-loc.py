#!/usr/bin/env python3
"""Read-only verifier for the frozen skill source-path LOC audit.

Python stdlib and read-only Git only. No builds, source edits, fetches, or Git
state writes. Full source identities are pinned; the historical Skills ledger
is inherited without altering it. This does not establish remote publication.
"""
import argparse
import difflib
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
KEYS = ('production', 'tests_and_test_support', 'benchmark_example')
SKILLS_COMMIT = 'e2785bc7ebf6102b1d4d30e34bad40d64ff994c7'
SKILLS_TREE = 'e41551e2cdc390c040820870eede7fdd2d4363ce'
BASE_COMMIT = '2ffbc323b9ad006683c2fef1eafa23f4990d8da5'
BASE_TREE = '529ba4b5b54031db5d40c63413f1d1f5df6e3c21'
FREEZE_SHA = '0a9f8d4edac1b664b6d917727683f61cdb31da5d19fba05de43c9a026f889c31'
LEDGER_PATH = 'rust/docs/validation/loc-project-skills-2026-10-07-delta.json'
LEDGER_SHA = 'e530726af07bee1382e9b545076d15200e16b6f382d9380b028a944a6604f203'
VERIFIER_PATH = 'rust/scripts/verify-loc-project-skills-2026-10-07.py'
VERIFIER_SHA = 'e244dc2bc2d881903992e952c28075290a7c9a543a6f5a0c8cf659cadb648e75'
CORE = 'rust/crates/bello-agent-core/'
RESOURCE = CORE + 'src/project_resources.rs'
SOURCE = CORE + 'src/project_resources/source_path.rs'
IDENTITY = CORE + 'src/project_resources/identity_tests.rs'
NATIVE = CORE + 'tests/project_skills_native.rs'
READ_TEST = 'rust/crates/bello-agent-app/src/transcript_read_native_ui_tests.rs'
EXPECTED_PATHS = sorted((RESOURCE, SOURCE, IDENTITY, NATIVE))
COMP = CORE + 'src/compaction_runtime_tests.rs'
BASH_LEDGER_PATH = 'rust/docs/validation/bash-workflow-2026-10-07/loc/loc-bash-workflow-2026-10-07-delta.json'
BASH_LEDGER_SHA = 'bd418b263e420f78df1cb9420fd928dbca5987e89cc5c0b670da9c3ce1e24427'
FINAL_BASH_VERIFIER_PATH = 'rust/scripts/verify-loc-bash-final-2026-10-07.py'
FINAL_BASH_VERIFIER_SHA = 'a8a18ee7339b6865e8f5523afccd9e488494a072208da1211ceecacea75c62b4'
HISTORICAL_AUDIT_SHA = '01dffb9f3a31066147f69b1e0747d9239c55f24e9a6140c41fae0bc3cd7cebca'


class VerificationError(Exception):
    pass

def require(condition, message):
    if not condition:
        raise VerificationError(message)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def blob(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':')).encode()

def zero():
    return dict.fromkeys(KEYS, 0)

def nonblank(lines):
    return sum(bool(line.strip()) for line in lines)

def identity(data):
    return {'git_blob': blob(data), 'sha256': sha(data), 'bytes': len(data)}

def source_manifest(sources, rust=False):
    result = {p: identity(b) for p, b in sorted(sources.items())}
    if rust:
        for p, b in sources.items():
            result[p]['nonblank'] = nonblank(b.decode().splitlines())
    return result

def rust_only(sources):
    return {p: b for p, b in sources.items() if p.startswith('rust/') and p.endswith('.rs')}

def historical_manifest(sources):
    return {p: {'git_blob': blob(b), 'sha256': sha(b), 'nonblank': nonblank(b.decode().splitlines())}
            for p, b in sorted(rust_only(sources).items())}

def git(repo, *args):
    return subprocess.check_output(['git', '-C', str(repo), *args],
                                   env=dict(os.environ, GIT_OPTIONAL_LOCKS='0'))

def verify_ref(repo, ref, required_tree):
    actual = git(repo, 'rev-parse', ref + '^{tree}').decode().strip()
    require(actual == required_tree, 'baseline/tree identity differs')

def git_sources(repo, ref):
    entries = []
    for row in git(repo, 'ls-tree', '-rz', ref).split(b'\0'):
        if row:
            meta, name = row.split(b'\t', 1)
            mode, kind, oid = meta.decode().split()
            require(kind == 'blob', 'non-blob source entry')
            entries.append((name.decode(), oid))
    request = ''.join(oid + '\n' for _, oid in entries).encode()
    result = subprocess.run(['git', '-C', str(repo), 'cat-file', '--batch'], input=request,
                            capture_output=True, check=True,
                            env=dict(os.environ, GIT_OPTIONAL_LOCKS='0')).stdout
    cursor, sources = 0, {}
    for name, oid in entries:
        end = result.index(b'\n', cursor)
        response_oid, kind, size = result[cursor:end].decode().split()
        require(response_oid == oid and kind == 'blob', 'Git blob response differs')
        cursor = end + 1
        data = result[cursor:cursor+int(size)]
        require(blob(data) == oid, 'Git blob digest differs')
        sources[name] = data
        cursor += int(size) + 1
    require(cursor == len(result), 'unconsumed Git blob output')
    return sources

def directory_sources(root):
    sources = {}
    for directory, dirs, files in os.walk(root):
        dirs[:] = sorted(d for d in dirs if d not in ('.git', 'target'))
        for filename in sorted(files):
            path = Path(directory) / filename
            name = path.relative_to(root).as_posix()
            require(not path.is_symlink(), 'unexpected candidate symlink: ' + name)
            sources[name] = path.read_bytes()
    return sources

def span(lines, start, end, category, reason):
    require(1 <= start <= end <= len(lines), 'classification range invalid')
    return {'start': start, 'end': end, 'classification': category, 'reason': reason,
            'start_text': lines[start-1], 'end_text': lines[end-1],
            'nonblank': nonblank(lines[start-1:end]),
            'source_sha256': sha('\n'.join(lines[start-1:end]).encode())}

def labels_for(lines, spans):
    labels = [None] * len(lines)
    for record in spans:
        for i in range(record['start']-1, record['end']):
            require(labels[i] is None, 'overlapping classification spans')
            labels[i] = record['classification']
    require(all(label in KEYS for label in labels), 'incomplete classification spans')
    return labels

def counts(lines, labels):
    require(len(lines) == len(labels), 'line/category length differs')
    output = zero()
    for line, label in zip(lines, labels):
        require(label in output, 'unknown category')
        if line.strip():
            output[label] += 1
    return output

def evidence(before, after, old_labels, new_labels):
    preserved, changed, delta = [], [], zero()
    for tag, a, b, c, d in difflib.SequenceMatcher(a=before, b=after, autojunk=False).get_opcodes():
        if tag == 'equal':
            for i, j in zip(range(a, b), range(c, d)):
                require(not before[i].strip() or old_labels[i] == new_labels[j],
                        'unchanged nonblank line reclassified')
            preserved.append({'before_start': a+1, 'after_start': c+1, 'line_count': b-a,
                              'nonblank_counts': counts(before[a:b], old_labels[a:b]),
                              'source_sha256': sha('\n'.join(before[a:b]).encode())})
        else:
            for side, lines, labels, start, end, sign in (
                    ('before', before, old_labels, a, b, -1),
                    ('after', after, new_labels, c, d, 1)):
                cursor = start
                while cursor < end:
                    label, stop = labels[cursor], cursor+1
                    while stop < end and labels[stop] == label:
                        stop += 1
                    amount = nonblank(lines[cursor:stop])
                    delta[label] += sign * amount
                    changed.append({'operation': tag, 'side': side, 'start': cursor+1,
                                    'end': stop, 'classification': label, 'nonblank': amount,
                                    'signed_delta': sign * amount,
                                    'source_sha256': sha('\n'.join(lines[cursor:stop]).encode())})
                    cursor = stop
    return preserved, changed, delta

def categories(path, data, after):
    lines = data.decode().splitlines()
    if not lines:
        return [], []
    if path == RESOURCE and after:
        require(lines[22:25] == ['#[cfg(all(test, unix))]', 'mod identity_tests;', 'mod source_path;'],
                'positive test-only module anchor differs')
        spans = [span(lines, 1, 22, KEYS[0], 'Production resource composition'),
                 span(lines, 23, 24, KEYS[1], 'Positive cfg(all(test, unix)) module declaration, including attribute'),
                 span(lines, 25, len(lines), KEYS[0], 'Production module declaration and resource composition')]
    else:
        category = KEYS[1] if path in (IDENTITY, NATIVE, READ_TEST, COMP) else KEYS[0]
        reason = ('Entire cfg(all(test, unix))-gated private test module' if path == IDENTITY else
                  'Cargo integration test target, including macOS-only attribute and fixtures' if path == NATIVE else
                  'Inherited whole native UI test module' if path == READ_TEST else
                  'Inherited whole positive cfg(test)-gated compaction runtime test module' if path == COMP else
                  'Private production helper; macOS/non-macOS platform gates are not test gates' if path == SOURCE else
                  'Inherited production resource composition')
        spans = [span(lines, 1, len(lines), category, reason)]
    return spans, labels_for(lines, spans)

def file_record(path, old, new, origin):
    old_data, new_data = old.get(path, b''), new.get(path, b'')
    old_lines, new_lines = old_data.decode().splitlines(), new_data.decode().splitlines()
    old_spans, old_labels = categories(path, old_data, False)
    new_spans, new_labels = categories(path, new_data, True)
    preserved, changed, delta = evidence(old_lines, new_lines, old_labels, new_labels)
    sides = {}
    for side, data, lines, spans, labels, exists in (
            ('before', old_data, old_lines, old_spans, old_labels, path in old),
            ('after', new_data, new_lines, new_spans, new_labels, path in new)):
        sides[side] = {'source': identity(data) if exists else None,
                       'physical_lines': len(lines), 'nonblank': nonblank(lines),
                       'counts': counts(lines, labels), 'classification_spans': spans}
    require(delta == {k: sides['after']['counts'][k] - sides['before']['counts'][k] for k in KEYS},
            'changed-line delta does not reconcile')
    return {'path': path, 'before_classification_origin': origin, **sides,
            'preserved_line_ranges': preserved, 'changed_line_spans': changed, 'delta': delta}

def aggregate(entries, key):
    result = zero()
    for record in entries:
        for category in KEYS:
            result[category] += record[key][category]
    return result

def make_report(skills, old, new, freeze_bytes, ledger_copy, bash_copy, historical_bash, historical_audit):
    require(sha(freeze_bytes) == FREEZE_SHA, 'frozen six-file manifest hash differs')
    freeze = json.loads(freeze_bytes)
    require(sha(skills[LEDGER_PATH]) == LEDGER_SHA, 'immutable historical Skills ledger hash differs')
    require(ledger_copy == skills[LEDGER_PATH] == old[LEDGER_PATH] == new[LEDGER_PATH],
            'prior Skills ledger changed')
    require(sha(skills[VERIFIER_PATH]) == VERIFIER_SHA, 'historical Skills verifier hash differs')
    prior = json.loads(skills[LEDGER_PATH])
    require(prior['after_rust_sources'] == historical_manifest(skills), 'historical Skills source manifest differs')
    require(prior['after_counts'] == dict(zip(KEYS, (42590, 56228, 1192))), 'historical Skills counts differ')
    require(prior['after_total'] == sum(v['nonblank'] for v in historical_manifest(skills).values()),
            'historical Skills physical count differs')
    require(sha(bash_copy) == BASH_LEDGER_SHA, 'immutable historical Bash ledger hash differs')
    require(bash_copy == old[BASH_LEDGER_PATH] == new[BASH_LEDGER_PATH], 'prior Bash ledger changed')
    require(sha(old[FINAL_BASH_VERIFIER_PATH]) == FINAL_BASH_VERIFIER_SHA, 'published baseline verifier hash differs')
    bash = json.loads(bash_copy)
    require(bash['before_rust_sources'] == historical_manifest(skills), 'historical Bash before manifest differs')
    require(bash['after_rust_sources'] == historical_manifest(historical_bash), 'historical Bash after manifest differs')
    require(bash['after_counts'] == dict(zip(KEYS, (43570, 58052, 1192))), 'historical Bash counts differ')
    require(bash['before_counts'] == prior['after_counts'], 'historical count chain differs')
    require(bash['after_total'] == sum(v['nonblank'] for v in historical_manifest(historical_bash).values()),
            'historical Bash physical count differs')
    require(sha(historical_audit) == HISTORICAL_AUDIT_SHA, 'historical c0 source-path audit changed')
    historical = json.loads(historical_audit)
    origin = {'kind': 'immutable_prior_skills_ledger', 'path': LEDGER_PATH,
              'git_blob': blob(skills[LEDGER_PATH]), 'sha256': LEDGER_SHA}
    bash_origin = {'kind': 'immutable_prior_bash_ledger', 'path': BASH_LEDGER_PATH,
                   'git_blob': blob(bash_copy), 'sha256': BASH_LEDGER_SHA}
    bridge_paths = sorted(p for p in historical_bash.keys() | rust_only(old).keys()
                          if historical_bash.get(p) != old.get(p))
    require(bridge_paths == sorted([READ_TEST, COMP]), 'published-baseline Rust bridge differs')
    # Neither bridge file changed in the earlier Bash slice. Inherit the Skills
    # ledger's exact-blob whole-test classifications, then count changed lines.
    require(historical_bash[READ_TEST] == skills[READ_TEST] and historical_bash[COMP] == skills[COMP],
            'bridge preimages differ from exact inherited Skills classifications')
    read_origin = next(f for b in prior['baseline_bridges'] for f in b['files']
                      if f['path'] == READ_TEST and f['after_source']['git_blob'] == blob(skills[READ_TEST]))
    comp_origin = next(f for f in prior['files'] if f['path'] == COMP)
    require(read_origin['after']['counts'] == dict(zip(KEYS, (0, 202, 0))), 'native Read support origin differs')
    require(comp_origin['after_blob'] == blob(skills[COMP]) and
            comp_origin['after']['counts'] == dict(zip(KEYS, (0, 782, 0))), 'compaction support origin differs')
    require(comp_origin['after']['reviewed_support_ranges'] == [{
        'start': 1, 'end': 794, 'reason': 'entire test or explicit fixture-only module',
        'start_text': 'use super::*;', 'end_text': '}'}], 'compaction inherited support extent differs')
    require(read_origin['after']['reviewed_support_ranges'] == [{
        'start': 1, 'end': 204, 'reason': 'entire test or explicit fixture-only module',
        'start_text': '//! Fake GPUI platform + real native read + disposable loopback provider.', 'end_text': '}'}],
        'native Read inherited support extent differs')
    require(b'#[cfg(test)]\n#[path = "compaction_runtime_tests.rs"]\nmod tests;' in old[CORE+'src/compaction_runtime.rs'],
            'compaction positive test gate differs')
    bridge_files = [file_record(path, historical_bash, old,
                    {**origin, 'record': 'baseline_bridges final after side' if path == READ_TEST else 'files after side'})
                    for path in bridge_paths]
    bridge_delta = aggregate(bridge_files, 'delta')
    require(bridge_delta == dict(zip(KEYS, (0, 31, 0))), 'published-baseline bridge total differs')
    for row in bridge_files:
        require(row['delta'] == dict(zip(KEYS, (0, 11 if row['path'] == READ_TEST else 20, 0))),
                'published-baseline bridge file delta differs')
    before_counts = {k: bash['after_counts'][k] + bridge_delta[k] for k in KEYS}
    require(before_counts == dict(zip(KEYS, (43570, 58083, 1192))), 'published baseline category totals differ')
    changed = sorted(p for p in old.keys() | new.keys() if old.get(p) != new.get(p))
    require(changed == sorted(row['path'] for row in freeze), 'candidate full changed-file set differs')
    for record in freeze:
        path = record['path']
        require(path in new and sha(new[path]) == record['sha256'] and len(new[path]) == record['bytes'],
                'frozen candidate source hash/length differs: ' + path)
        require((sha(old[path]) if path in old else None) == record['baseline_sha256'],
                'frozen baseline source hash differs: ' + path)
        old_historical = historical['full_source_manifests']['before'].get(path)
        new_historical = historical['full_source_manifests']['after'][path]
        require((old_historical['sha256'] if old_historical else None) == record['baseline_sha256'],
                'preimage differs from prior c0 source-path review: ' + path)
        require(record['same_as_prior_freeze'] == (new_historical['sha256'] == record['sha256']),
                'same-as-prior identity attribution differs: ' + path)
        require(record['same_as_prior_freeze'] == (path != 'rust/docs/validation/project-skills-native-oracle.md'),
                'unexpected change from prior source-path freeze')
    old_rust, new_rust = rust_only(old), rust_only(new)
    paths = sorted(p for p in old_rust.keys() | new_rust.keys() if old_rust.get(p) != new_rust.get(p))
    require(paths == EXPECTED_PATHS, 'changed Rust path set differs')
    files = []
    for path in paths:
        if path in old:
            row = next(f for f in prior['files'] if f['path'] == path)
            require(row['after_sha256'] == sha(old[path]) and row['after_blob'] == blob(old[path]),
                    'before-file exact-blob classification identity differs')
            entry_origin = {**origin, 'record': 'files after side'}
        else:
            entry_origin = {'kind': 'new_file'}
        record = file_record(path, old, new, entry_origin)
        if path in old:
            require(row['after']['counts'] == record['before']['counts'], 'inherited file counts differ')
        files.append(record)
    require(files == historical['files'], 'source-path review/spans differ from prior exact-source audit')
    delta = aggregate(files, 'delta')
    after_counts = {k: before_counts[k] + delta[k] for k in KEYS}
    old_manifest, new_manifest = source_manifest(old_rust, True), source_manifest(new_rust, True)
    require(sum(before_counts.values()) == sum(v['nonblank'] for v in old_manifest.values()), 'baseline physical count differs')
    require(sum(after_counts.values()) == sum(v['nonblank'] for v in new_manifest.values()), 'candidate physical count differs')
    preserved = zero()
    for entry in files:
        for record in entry['preserved_line_ranges']:
            for key in KEYS:
                preserved[key] += record['nonblank_counts'][key]
    return {
        'schema': 2,
        'method': 'Nonblank physical Rust lines including comments. Inherit immutable exact-blob classifications. Positive test-only and fixture spans include attributes. Equal nonblank lines under SequenceMatcher(autojunk=False) retain their categories. Only changed spans contribute to the delta.',
        'scope': 'Owned rust/**/*.rs only; dependencies/build output, Swift, logs, recovery.rs.txt and non-Rust files excluded. Shared workbench is counted only in BelloBox; no workbench delta here.',
        'checkpoint_status': 'isolated_frozen_source_audited_publication_unverified', 'publication_commit': None,
        'before_commit': BASE_COMMIT, 'before_tree': BASE_TREE,
        'historical_skills_commit': SKILLS_COMMIT, 'historical_skills_tree': SKILLS_TREE,
        'immutable_prior_skills_ledger': origin, 'immutable_prior_skills_counts': prior['after_counts'],
        'immutable_prior_bash_ledger': bash_origin, 'immutable_prior_bash_counts': bash['after_counts'],
        'published_bash_verifier': {'path': FINAL_BASH_VERIFIER_PATH, 'sha256': FINAL_BASH_VERIFIER_SHA,
                                   'git_blob': blob(old[FINAL_BASH_VERIFIER_PATH])},
        'historical_source_path_audit': {'filename': 'historical-c0-source-path-audit.json',
            'sha256': HISTORICAL_AUDIT_SHA, 'before_commit': historical['before_commit'],
            'all_four_rust_file_and_span_records_identical': True,
            'changed_since_prior_freeze': ['rust/docs/validation/project-skills-native-oracle.md']},
        'baseline_bridge': {'from': 'immutable historical Bash after_rust_sources', 'after_commit': BASE_COMMIT,
                            'files': bridge_files, 'delta': bridge_delta},
        'candidate_freeze': {'filename': 'frozen-six-file-manifest.json', 'sha256': FREEZE_SHA,
                             'file_count': 6, 'rust_file_count': 4},
        'full_source_manifests': {'before': source_manifest(old), 'after': source_manifest(new)},
        'full_source_manifest_sha256': {'before': sha(canonical(source_manifest(old))), 'after': sha(canonical(source_manifest(new)))},
        'before_rust_sources': old_manifest, 'after_rust_sources': new_manifest,
        'rust_source_manifest_sha256': {'before': sha(canonical(old_manifest)), 'after': sha(canonical(new_manifest))},
        'rust_file_count': {'before': len(old_rust), 'after': len(new_rust), 'changed': len(files),
                           'unchanged': len(old_rust.keys() & new_rust.keys()) - sum(p in old_rust and p in new_rust for p in paths), 'new': 2},
        'before_counts': before_counts, 'delta': delta, 'after_counts': after_counts,
        'before_total': sum(before_counts.values()), 'after_total': sum(after_counts.values()),
        'preserved_nonblank_counts_in_changed_files': preserved, 'inherited_classification_adjustments': [],
        'files': files, 'non_rust_changed_files': [row for row in freeze if not row['path'].endswith('.rs')],
        'limits': 'Source-volume and provenance audit only. No builds or functional tests run. Does not establish parity, GUI/macOS acceptance, speed, memory, completion percentage, or remote publication.'}

def verify_report(report, *inputs):
    expected = make_report(*inputs)
    require(report == expected, 'ledger content differs from independently recomputed evidence/classification')
    return {'result': 'passed', 'baseline': BASE_COMMIT,
            'candidate_manifest_sha256': expected['full_source_manifest_sha256']['after'],
            'delta': expected['delta'], 'counts': expected['after_counts'], 'total': expected['after_total'],
            'rust_files': expected['rust_file_count'],
            'preserved_nonblank_lines_verified': sum(expected['preserved_nonblank_counts_in_changed_files'].values()),
            'prior_skills_ledger_unchanged': True, 'prior_bash_ledger_unchanged': True,
            'historical_source_path_review_unchanged': True, 'publication_verified': False}

def load_inputs(args):
    verify_ref(args.repo, args.baseline_ref, BASE_TREE)
    verify_ref(args.repo, SKILLS_TREE, SKILLS_TREE)
    skills, old = git_sources(args.repo, SKILLS_TREE), git_sources(args.repo, args.baseline_ref)
    new = directory_sources(args.source_root)
    bash_copy = (HERE/'immutable-prior-bash-ledger.json').read_bytes()
    require(sha(bash_copy) == BASH_LEDGER_SHA, 'historical Bash ledger hash differs before source lookup')
    bash = json.loads(bash_copy)
    historical_bash = rust_only(old)
    for path, meta in bash['after_rust_sources'].items():
        if sha(historical_bash[path]) != meta['sha256']:
            historical_bash[path] = git(args.repo, 'cat-file', 'blob', meta['git_blob'])
            require(sha(historical_bash[path]) == meta['sha256'], 'historical Bash blob digest differs')
    return skills, old, new, (HERE/'frozen-six-file-manifest.json').read_bytes(), (HERE/'immutable-prior-skills-ledger.json').read_bytes(), bash_copy, historical_bash, (HERE/'historical-c0-source-path-audit.json').read_bytes()

def arguments():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', required=True, type=Path)
    parser.add_argument('--source-root', required=True, type=Path)
    parser.add_argument('--baseline-ref', default=BASE_TREE,
                        help='Must resolve to the exact 2ffbc323 baseline tree; tree/commit aliases accepted')
    parser.add_argument('--report', type=Path, default=HERE/'loc-skill-source-path-delta.json')
    return parser.parse_args()

def main():
    args = arguments()
    result = verify_report(json.loads(args.report.read_text()), *load_inputs(args))
    print(json.dumps(result, indent=2))

if __name__ == '__main__':
    try:
        main()
    except (VerificationError, subprocess.CalledProcessError) as error:
        print('VERIFICATION FAILED: ' + str(error), file=sys.stderr)
        sys.exit(1)
